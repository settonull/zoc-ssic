from .cnn import simple_CNN

